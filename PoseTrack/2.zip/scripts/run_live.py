import cv2
import time
import argparse
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.pose.mediapipe_runner import MediaPipeRunner
from src.processing.joint_angle_estimator import compute_all
from src.processing.angle_filter import AngleFilterSystem
from src.streaming.udp_streamer import UdpAngleStreamer
from config.config import Config

def main():
    parser = argparse.ArgumentParser(description="Run Real-Time Pose Estimation to Unity")
    parser.add_argument("--host", default=Config.UDP_IP, help="UDP Host IP")
    parser.add_argument("--port", type=int, default=Config.UDP_PORT, help="UDP Port")
    parser.add_argument("--filter", default="kalman", choices=["kalman", "ema", "ma", "sg"],
                        help="Filter type: kalman (default), ema, ma (moving average), sg (Savitzky-Golay)")
    parser.add_argument("--camera", type=int, default=Config.CAMERA_ID, help="Camera ID")
    parser.add_argument("--video", type=str, default=None, help="Optional video file instead of camera")
    args = parser.parse_args()

    print(f"Starting Real-Time Pipeline on {args.host}:{args.port} using {args.filter} filter")

    pose_runner = MediaPipeRunner(
        min_detection_confidence=Config.MIN_DETECTION_CONFIDENCE,
        min_tracking_confidence=Config.MIN_TRACKING_CONFIDENCE
    )
    filter_sys = AngleFilterSystem(filter_type=args.filter)
    streamer = UdpAngleStreamer(host=args.host, port=args.port, hz=Config.OUTPUT_VIDEO_FPS)
    
    if args.video:
        cap = cv2.VideoCapture(args.video)
    else:
        backends = [
            (args.camera, cv2.CAP_MSMF),
            (args.camera, 0),
            (1, cv2.CAP_MSMF),
        ]
        cap = None
        for idx, backend in backends:
            _cap = cv2.VideoCapture(idx, backend) if backend else cv2.VideoCapture(idx)
            if _cap.isOpened():
                cap = _cap
                print(f"Opened camera index={idx} backend={'MSMF' if backend == cv2.CAP_MSMF else 'auto'}")
                break
            _cap.release()
        if cap is None:
            cap = cv2.VideoCapture()

    if not cap.isOpened():
        print("Error: Could not open video source.")
        print("  > Check: Settings > Privacy > Camera - ensure camera access is ON for desktop apps")
        print("  > Check: No other app (Teams, Zoom, OBS) is holding the camera")
        print("  > Try: --camera 1 or --camera 2")
        print("  > Try: --video path/to/file.mp4  to use a video file instead")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, Config.FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, Config.FRAME_HEIGHT)

    # MSMF on Windows reports isOpened() = True before the hardware is ready.
    # Drain a few frames and add a short delay so the first real read succeeds.
    if not args.video:
        print("Warming up camera...")
        for _ in range(10):
            cap.read()
        time.sleep(0.5)

    streamer.start()

    print("Pipeline running. Press 'q' to stop.")
    consecutive_failures = 0

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                if args.video:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue
                consecutive_failures += 1
                if consecutive_failures >= 30:
                    print("Error: Camera stopped delivering frames. Check that no other app took over the camera.")
                    break
                time.sleep(0.033)
                continue
            consecutive_failures = 0

            image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            landmarks = pose_runner.process(image_rgb)

            if landmarks is not None:
                raw_angles = compute_all(landmarks)
                filtered_angles = filter_sys.update(raw_angles)
                
                streamer.update_angles(
                    shoulder_pitch = filtered_angles["shoulder_elevation"],
                    shoulder_yaw   = filtered_angles["shoulder_yaw"],
                    shoulder_roll  = filtered_angles["shoulder_roll"],
                    elbow_flex     = filtered_angles["elbow_flexion"]
                )

            cv2.imshow("Real-Time Feed", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    except KeyboardInterrupt:
        pass
    finally:
        print("Shutting down...")
        cap.release()
        cv2.destroyAllWindows()
        pose_runner.close()
        streamer.stop()

if __name__ == "__main__":
    main()
